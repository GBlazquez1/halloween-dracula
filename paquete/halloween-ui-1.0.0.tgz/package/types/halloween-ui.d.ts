import * as i0 from "@angular/core";
import { OnInit } from "@angular/core";
export declare class HalloweenUi implements OnInit {
  constructor();
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<HalloweenUi, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HalloweenUi, "lib-halloween-ui", never, {}, {}, never, never, true, never>;
}
export declare class MonsterCardComponent {
  imagen: string;
  titulo: string;
  texto: string;
  mensaje: string;
  mostrarMensaje(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "lib-monster-card", never, {
    "imagen": {
      "alias": "imagen";
      "required": false;
    };
    "titulo": {
      "alias": "titulo";
      "required": false;
    };
    "texto": {
      "alias": "texto";
      "required": false;
    };
    "mensaje": {
      "alias": "mensaje";
      "required": false;
    };
  }, {}, never, never, true, never>;
}