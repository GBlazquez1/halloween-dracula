import * as i0 from "@angular/core";
import { Component, Input } from "@angular/core";
var HalloweenUi = class HalloweenUi {
	constructor() {}
	ngOnInit() {}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.3.0",
			ngImport: i0,
			type: HalloweenUi,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.3.0",
			type: HalloweenUi,
			isStandalone: true,
			selector: "lib-halloween-ui",
			ngImport: i0,
			template: "",
			isInline: true
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.3.0",
	ngImport: i0,
	type: HalloweenUi,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-halloween-ui",
			template: "",
			imports: []
		}]
	}],
	ctorParameters: () => []
});
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.imagen = "";
		this.titulo = "";
		this.texto = "";
		this.mensaje = "No deberías haber entrado...";
	}
	mostrarMensaje() {
		alert(this.mensaje);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.3.0",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.3.0",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "lib-monster-card",
			inputs: {
				imagen: "imagen",
				titulo: "titulo",
				texto: "texto",
				mensaje: "mensaje"
			},
			ngImport: i0,
			template: "<div class=\"tarjeta\">\n  <img [src]=\"imagen\" [alt]=\"titulo\">\n\n  <div class=\"contenido\">\n    <h2>{{ titulo }}</h2>\n\n    <p>{{ texto }}</p>\n\n    <button type=\"button\" (click)=\"mostrarMensaje()\">\n      Descubrir secreto\n    </button>\n  </div>\n</div>",
			styles: [".tarjeta{background:#1b1414;color:#f5eeee;border:2px solid #b32636;border-radius:12px;max-width:500px;margin:20px auto;overflow:hidden;box-shadow:0 0 12px #700d1d}img{display:block;width:100%;height:240px;object-fit:cover}.contenido{padding:18px}h2{color:#ff6575;font-family:Georgia,serif;text-shadow:2px 2px #000;margin-top:0}p{font-family:Arial,sans-serif;line-height:1.6}button{background:#a7192b;color:#fff;border:1px solid #ff6575;border-radius:6px;padding:12px 18px;cursor:pointer}button:hover{background:#c32238}button:active{transform:scale(.96)}button:focus-visible{outline:2px solid white;outline-offset:3px}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.3.0",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			standalone: true,
			template: "<div class=\"tarjeta\">\n  <img [src]=\"imagen\" [alt]=\"titulo\">\n\n  <div class=\"contenido\">\n    <h2>{{ titulo }}</h2>\n\n    <p>{{ texto }}</p>\n\n    <button type=\"button\" (click)=\"mostrarMensaje()\">\n      Descubrir secreto\n    </button>\n  </div>\n</div>",
			styles: [".tarjeta{background:#1b1414;color:#f5eeee;border:2px solid #b32636;border-radius:12px;max-width:500px;margin:20px auto;overflow:hidden;box-shadow:0 0 12px #700d1d}img{display:block;width:100%;height:240px;object-fit:cover}.contenido{padding:18px}h2{color:#ff6575;font-family:Georgia,serif;text-shadow:2px 2px #000;margin-top:0}p{font-family:Arial,sans-serif;line-height:1.6}button{background:#a7192b;color:#fff;border:1px solid #ff6575;border-radius:6px;padding:12px 18px;cursor:pointer}button:hover{background:#c32238}button:active{transform:scale(.96)}button:focus-visible{outline:2px solid white;outline-offset:3px}\n"]
		}]
	}],
	propDecorators: {
		imagen: [{ type: Input }],
		titulo: [{ type: Input }],
		texto: [{ type: Input }],
		mensaje: [{ type: Input }]
	}
});
export { HalloweenUi, MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map